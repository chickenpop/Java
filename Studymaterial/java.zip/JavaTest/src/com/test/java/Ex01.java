package com.test.java;

// 주석으로 필기할것
// 주석, Comment, Remark 
// 한줄 주석, Single Line Comment
// - 프로그래밍 코드는 아니지만, 코드에 기억해야할 내용을 작성한다.
// - 코드 설명, 나중에 확인, 전달 설명

/*
  
 	다중 라인 주석, MultiLine Comment
 	
  	window - show view - 창 살릴수 잇음
 	
*/

// 클래스, Class
// - public class Ex01 > 클래스 선언부(header)
// - {} > 클래스 구현부(body)
// - 코드의 집합
// 키워드와 키워드 사이에 공백과 엔터를 넣어도 정상 출력된다.

// "Ex01이라는 이름을 가진 클래스입니다."

public class Ex01 { 
	
	// 메소드, Method
	// - 코드의 집합
	// "main이라는 이름을 가진 메소드입니다."
	public static void main(String[] args) {
		
		// 명령어 > 문장 단위 구성
		
		// 문장(Statement)
		// 문장 종결자(;), 없으면 Error : Syntax error, insert ";" to complete BlockStatements
		System.out.println("첫번째 예제"); // 콘솔창에 출력하는 명령어
		
		// 이클립스 <-> 실시간 <-> javac.exe
		
		/*
		 
		 코드 작성
		 - 영문자
		 - 숫자
		 - 한글
		 - 특수문자, 영어명도 알아두기
		 
		 ~(tilde), !, @(si), #(샵, 해시), $, %, ^(xor, caret), &, *
		 `(역따음표, back tick, back quote), ', ", -, _, |(vertical bar, pipe), ?, /(slash), \(back slash)
		 
		 
		 () : 소괄호
		 [] : 대괄호
		 {} : 중괄호
		 <> : 화살표 괄호
		 
		 
		 A > B   A greater than B
		 A >= B  A greater than equals B
		 
		 
		 */
		
	}
	
}
