package com.test.java;

public class Ex03_Variable {
	
	public static void main(String[] args) {
		
		// Ex03_Variable.java

		// 변수, Variable
		// - 개발자가 명령어를 사용해서 메모리 할당받은 공간
		// - 목적: 원하는 데이터를 읽거나 쓰기 위한 공간
		
		// 변수
		// 1. 생성하기
		// - 자료형 변수명;
		byte kor;
		
		// 2. 초기화하기
		// - 변수 = 값;
		kor = 100;
		
		// 3. 사용하기
		System.out.println(kor); // 이거 뭐니? 국어점수.. > 표현으로 의미를 알 수 있다.	
		System.out.println(100); // 이거뭐니? > ????? > 표현으로 의미를 알 수 없다;;
		
		// Task Tags 대문자로 적어야함
		// todo		나중에 해야할일
		// fixme 	나중에 수정할 내용
		// xxx		나머지...
		// 직접 만드는 것도 가능 test
		
	}
	
}
