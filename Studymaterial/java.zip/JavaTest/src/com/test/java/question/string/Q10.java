package com.test.java.question.string;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Q10 {

	public static void main(String[] args) throws Exception {

		// 10번 문제 한글 숫자 
		
		// 객체, 변수
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String[] korNumName = { "", "십", "백", "천", "만", "십", "백", "천"};
		String[] korNum = { "", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구" };
		
		System.out.print("금액(원):");
		String money = reader.readLine();
		StringBuilder result = new StringBuilder("");
		
		for(int i=0; i<money.length(); i++) {
			
			for(int j=1; j<=9; j++) {
				
				if(j == (money.charAt(i)-'0')) {
					result.append(korNum[j]);
					break;
				}
				
			}
			
			// 단위 
			result.append(korNumName[korNumName.length-(korNumName.length-money.length())-i-1]);
			
		}
		
		System.out.printf("일금 %s원\n", result);
		
		
	}

}
