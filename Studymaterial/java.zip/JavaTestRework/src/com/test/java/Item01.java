package com.test.java;

// 클래스명 > 의미 없이..
public class Item01 {

	public static void main(String[] args) {
		
		// [SUMMARY] 주석 생성 (2022. 3. 12. 오후 8:16:38)
		
		// 한줄 주석
		
		/*
		
			다중 라인 주석
		
		*/
		
		/**
		 * 
		 *  Document 주석
		 * 
		 */
		
		
	}
	
}
