package com.test.java;

public class Item02 {

	public static void main(String[] args) {
		
		// [SUMMARY] 표기법 (2022. 3. 12. 오후 8:16:54)
		
		// 파스칼 표기법
		
		int EnglishScore;
		
		// 캐멀 표기법
		
		int englishScore;
		
	}
	
}
