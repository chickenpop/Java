package com.test.java;

public class Item03 {

	public static void main(String[] args) {
		
		// [SUMMARY] MAX, MIN 값 구하기 (2022. 3. 12. 오후 8:17:14)
		// 자료형.MAX_VALUE, MIN_VALUE
		
		int inum = Integer.MAX_VALUE;
		System.out.println(inum);
		
		double dnum = Double.MAX_VALUE;
		System.out.println(dnum);
		
		
		inum = Integer.MIN_VALUE;
		System.out.println(inum);
		
		dnum = Double.MIN_VALUE;
		System.out.println(dnum);
		
		
		
	}
	
}
