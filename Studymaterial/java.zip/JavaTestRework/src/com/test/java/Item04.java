package com.test.java;

public class Item04 {

	public static void main(String[] args) {
	
		// [SUMMARY] 형식 문자 자릿수 지정 (2022. 3. 12. 오후 8:17:29)
		// %숫자d, d 이외에 모든 형식 문자 적용 가능
		
		int num = 12;
		
		System.out.printf("%5d\n", num);  // 우측 정렬
		System.out.printf("%-5d\n", num); // 좌측 정렬
		
	}
	
}
