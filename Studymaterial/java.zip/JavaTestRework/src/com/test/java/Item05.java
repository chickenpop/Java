package com.test.java;

public class Item05 {

	public static void main(String[] args) {
		
		// [SUMMARY] 형식 문자 천단위 기호 (2022. 3. 12. 오후 8:17:42)
		// %d, %f 적용 가능
		
		int price = 1235467890;
		
		System.out.printf("%,d", price);
		
	}
	
}
