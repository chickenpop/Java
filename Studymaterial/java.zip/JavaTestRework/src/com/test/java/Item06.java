package com.test.java;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Item06 {

	public static void main(String[] args) throws Exception {

		// [SUMMARY] BufferedReader 선언 및 사용 (2022. 3. 12. 오후 8:17:54)
		// 예외 처리 : throws Exception 필요함
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		String bf = reader.readLine();
		
		System.out.println(bf);
		
	}

}
