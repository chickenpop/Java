package com.test.java;

public class Item07 {

	public static void main(String[] args) {

		// [SUMMARY] 소문자 a 대문자 A 코드값 (2022. 3. 12. 오후 8:18:16)
		
		char ch = 'a';
		
		System.out.println((int)ch);
		
		ch = 'A';
		
		System.out.println((int)ch);
		
	}

}
