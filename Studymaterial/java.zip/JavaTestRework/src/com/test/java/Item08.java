package com.test.java;

public class Item08 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열을 값형 자료형으로 형변환 (2022. 3. 12. 오후 8:16:19)
	
		String str = "12";
		
		int inum = Integer.parseInt(str);
		System.out.println(inum);
		
		double dnum = Double.parseDouble(str);
		System.out.println(dnum);
		
	}

}
