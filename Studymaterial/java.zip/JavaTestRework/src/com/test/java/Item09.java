package com.test.java;

public class Item09 {

	public static void main(String[] args) {

		// [SUMMARY] 값형 자료형을 문자열로 형변환 (2022. 3. 12. 오후 8:20:51)
		
		int inum = 100;
		
		String str = String.valueOf(inum);
		System.out.println(str);
		
		
		
		double dnum = 123.456;
		
		str = String.valueOf(dnum);
		System.out.println(str);
		
	}

}
