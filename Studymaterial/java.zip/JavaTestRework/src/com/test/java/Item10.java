package com.test.java;

public class Item10 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 비교하기 (2022. 3. 12. 오후 8:23:42)
		
		String str1 = "홍길동";
		String str2 = "아무개";
		String str3 = "홍길동";
		
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		
	}

}
