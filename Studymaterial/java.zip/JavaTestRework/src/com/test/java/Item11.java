package com.test.java;

public class Item11 {

	public static void main(String[] args) {

		// [SUMMARY] 메소드 선언 및 사용 (2022. 3. 12. 오후 8:25:45)
		// 접근지정자 정적키워드 반환자료형 메소드명 인자리스트 { 구현 코드 }
		
		// 사용
		hello();
		
	} // main

	// 선언
	public static void hello() {
		
		System.out.println("Hello World!");
		
	}
	
} // class
