package com.test.java;

public class Item12 {

	public static void main(String[] args) {

		// [SUMMARY] 리턴문, 반환문 사용 (2022. 3. 12. 오후 8:28:59)
		
		int num = 0;
		num = getNum();
		
		System.out.println(num);
		
	}

	public static int getNum() { 

		return 10;
		
	}
	
}
