package com.test.java;

public class Item13 {

	public static void main(String[] args) {

		// [SUMMARY] Swap (2022. 3. 14. 오후 7:34:42)

		int a = 10;
		int b = 20;

		System.out.println(a + " " + b);

		int temp = a;
		a = b;
		b = temp;

		System.out.println(a + " " + b);

	}

}
