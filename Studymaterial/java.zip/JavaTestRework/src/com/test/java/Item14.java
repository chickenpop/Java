package com.test.java;

public class Item14 {

	public static void main(String[] args) {

		// [SUMMARY] 재귀메소드 - 팩토리얼 (2022. 3. 14. 오후 7:41:58)

		int n = 5;
		int result = factorial(n);
		System.out.printf("%d! = %d", n, result);

	}

	public static int factorial(int n) {
		return n == 1 ? 1 : n * factorial(n - 1);
	}


}
