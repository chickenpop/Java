package com.test.java;

import java.util.Calendar;

public class Item15 {

	public static void main(String[] args) {

		// [SUMMARY] Calendar 상수 정보(2022. 3. 14. 오후 7:49:58)

		Calendar c1 = Calendar.getInstance();

		System.out.println(c1.get(Calendar.YEAR)); // 연도
		System.out.println(c1.get(Calendar.MONTH)); // 월(0~11) 0~23
		System.out.println(c1.get(Calendar.DATE)); // 날짜(일)
		System.out.println(c1.get(Calendar.HOUR)); // 시(12H) 0~11
		System.out.println(c1.get(Calendar.MINUTE)); // 분
		System.out.println(c1.get(Calendar.SECOND)); // 초
		System.out.println(c1.get(Calendar.MILLISECOND)); // 밀리초(1/1000)
		System.out.println(c1.get(Calendar.AM_PM)); // 오전(0), 오후(1)


		System.out.println(c1.get(Calendar.DAY_OF_YEAR)); // 일(올해)
		System.out.println(c1.get(Calendar.DAY_OF_MONTH));// 일(달)
		System.out.println(c1.get(Calendar.DAY_OF_WEEK)); // 일(요일) 1(일)~7(토)

		System.out.println(c1.get(Calendar.WEEK_OF_YEAR)); // 주(올해)
		System.out.println(c1.get(Calendar.WEEK_OF_MONTH)); // 주(이번달) - 목요일이 포함된 주부터 첫주

		System.out.println(c1.get(Calendar.HOUR_OF_DAY)); // 시(24H)
	}

}
