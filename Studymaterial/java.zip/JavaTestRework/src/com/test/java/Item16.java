package com.test.java;

import java.util.Calendar;

public class Item16 {

	public static void main(String[] args) {

		// [SUMMARY] Calendar 선언 및 사용 (2022. 3. 14. 오후 7:52:09)

		Calendar now = Calendar.getInstance();

		System.out.printf("지금은 %s %d시 %d분입니다.\n", now.get(Calendar.AM_PM) == 0 ? "오전" : "오후",
				now.get(Calendar.HOUR), now.get(Calendar.MINUTE));

	}

}
