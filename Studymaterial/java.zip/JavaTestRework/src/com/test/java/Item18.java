package com.test.java;

import java.util.Date;

public class Item18 {

	public static void main(String[] args) {

		// [SUMMARY] Date 클래스 사용 (2022. 3. 15. 오후 10:58:48)

		Date date = new Date();

		// Tue Mar 15 22:59:29 KST 2022
		System.out.println(date);

	}

}
