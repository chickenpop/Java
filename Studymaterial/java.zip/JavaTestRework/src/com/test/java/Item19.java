package com.test.java;

import java.util.Calendar;

public class Item19 {

	public static void main(String[] args) {

		// [SUMMARY] Calendar set(), 시각 수정하기 (2022. 3. 15. 오후 11:05:42)

		Calendar christmas = Calendar.getInstance();

		// 2022-12-25 18:00:00 일요일
		christmas.set(2022, 11, 25, 18, 0, 0);
		System.out.printf("%tF %tT %tA\n", christmas, christmas, christmas);

	}

}
