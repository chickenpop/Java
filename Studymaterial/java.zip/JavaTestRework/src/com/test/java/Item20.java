package com.test.java;

import java.util.Calendar;

public class Item20 {

	public static void main(String[] args) {

		// [SUMMARY] Calendar add(), 시간 계산하기 (2022. 3. 15. 오후 11:07:50)

		Calendar now = Calendar.getInstance();

		// date 외 Calendar 상수 사용가능
		now.add(Calendar.DATE, 100);
		System.out.printf("현재로부터 100일후 : %tF\n", now);

		// 계산할때마다 초기화해줘야한다.
		now = Calendar.getInstance();
		now.add(Calendar.DATE, -50);
		System.out.printf("현재로부터 100일전 : %tF\n", now);
	}

}
