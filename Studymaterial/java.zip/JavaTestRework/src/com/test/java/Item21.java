package com.test.java;

public class Item21 {

	public static void main(String[] args) {

		// [SUMMARY] Tick 전용 메소드 (2022. 3. 15. 오후 11:11:26)

		// 현재 시각의 tick을 출력
		System.out.println(System.currentTimeMillis());

	}

}
