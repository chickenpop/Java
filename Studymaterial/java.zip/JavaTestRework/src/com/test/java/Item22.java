package com.test.java;

import java.util.Calendar;

public class Item22 {

	public static void main(String[] args) {

		// [SUMMARY] Tick 연산 (2022. 3. 15. 오후 11:14:43)

		Calendar now = Calendar.getInstance();
		Calendar christmas = Calendar.getInstance();

		christmas.set(2022, 11, 25, 0, 0, 0);

		// 현재 시각 - 특정 시각
		long nowTick = now.getTimeInMillis();
		long christmasTick = christmas.getTimeInMillis();

		// 1000 = 초, 60 = 분, 60 = 시, 24 = 일로 환산하려고 나눈다
		System.out.println((christmasTick - nowTick) / 1000 / 60 / 60 / 24);
	}

}
