package com.test.java;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Item23 {

	public static void main(String[] args) throws Exception {

		// [SUMMARY] 중첩 if으로 유효성 검사 (2022. 3. 15. 오후 11:17:37)

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		int score = Integer.parseInt(reader.readLine());

		// 조건
		// 1. (score >= 0 && score <= 100)
		// 1.1(score >= 60)
		// 1.2 else 절
		// 2. 100보다 크거나 0보다 작을때
		if (score >= 0 && score <= 100) {

			if (score >= 60) {
				System.out.println("합격");
			} else {
				System.out.println("불합격");
			}

		} else {

			System.out.println("점수는 0~100사이로 입력하세요.");

		}


	}

}
