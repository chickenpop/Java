package com.test.java;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Item24 {

	public static void main(String[] args) throws Exception{

		// [SUMMARY] switch문 특성 (2022. 3. 17. 오전 7:48:14)
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		// 요구사항] 인터넷 쇼핑물 > 상품 구매 > 옵션
		// 1. 노트북 + USB C타입 케이블 + 마우스패드
		// 2. 노트북 + USB C타입 케이블
		// 3. 노트북

		System.out.print("선택 : ");

		String input = reader.readLine();


		switch (input) {
			case "1":
				System.out.println("마우스패드");
			case "2":
				System.out.println("USB C타입 케이블");
			case "3":
				System.out.println("노트북");
				break;
		}
		
	}

}
