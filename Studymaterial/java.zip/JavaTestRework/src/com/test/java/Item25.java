package com.test.java;

import java.util.Calendar;

public class Item25 {

	public static void main(String[] args) {

		// [SUMMARY] Calendar 상수 월의 마지막일 (2022. 3. 17. 오전 7:58:19)
		// 주의 반복문에서 사용시 월이 바뀔 수 있음
		
		Calendar c1 = Calendar.getInstance();
		
		int lastDay = c1.getActualMaximum(Calendar.DATE);
		
		System.out.println(lastDay); // 이번달의 마지막 일
		
	}

}
