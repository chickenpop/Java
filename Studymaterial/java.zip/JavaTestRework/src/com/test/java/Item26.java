package com.test.java;

public class Item26 {

	public static void main(String[] args) {

		// [SUMMARY] Math 클래스 난수 생성 (2022. 3. 17. 오전 8:01:39)
		
		
		// 1~10까지의 수가 랜덤하게 생성
		// Math.random()은 0~0.9999.. 사이에 수 생성
		for(int i=0; i<5; i++) {
			
			int num = (int)(Math.random()*10) + 1;
			
			System.out.println(num);

		}
		

	}

}
