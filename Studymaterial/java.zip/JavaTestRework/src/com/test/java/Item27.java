package com.test.java;

public class Item27 {

	public static void main(String[] args) {

		// [SUMMARY] 윤년, 요일, 월의 마지막 (2022. 3. 20. 오전 11:14:31)
	
		int year = 2022; 
		int month = 3;
		int day = 20;
		String DayOfWeek = "";
		
		System.out.printf("윤년인가? %b\n", isLeafYear(year));
		System.out.printf("월의 마지막 일은? %d\n", getLastDay(year, month));	
		DayOfWeek = getDayOfWeek(year, month, day);
		System.out.printf("오늘의 요일은? %s\n", DayOfWeek);
		
	}

	// 윤년
	public static boolean isLeafYear(int year) {
		
		return (year%4==0 && year%100!=0) || year%400==0 ? true : false;
		
	}
	
	// 요일
	public static String getDayOfWeek(int year, int month, int date){
		
		int total = 0;
		
		total += getTotalYearDay(year);
		
		// 2022년 1월 1일 ~ 2월 28일
		total += getTotalMonthDay(year, month);
		total += date;
		
		if(total % 7 == 1) {
			return "월";
		} else if(total % 7 == 2) {
			return "화";
		} else if(total % 7 == 3) {
			return "수";
		} else if(total % 7 == 4) {
			return "목";
		} else if(total % 7 == 5) {
			return "금";
		} else if(total % 7 == 6) {
			return "토";
		} else {
			return "일";
		}
	}
	// 총 일수
	public static int getTotalMonthDay(int year, int month) {
		int total = 0;
		for(int i=1; i<month; i++) {
			total += getLastDay(year, i);
		}
		
		return total;
	}
	
	public static int getTotalYearDay(int year) {
		int total = 0;
		int date = 1;
		
		for(int i=1; i<year; i++) {
			if(isLeafYear(i)) {
				total += 366;
			} else {
				total += 365;
			}
		}
		return total;
	}
	
	// 달의 마지막(윤년 정보 필요)
	public static int getLastDay(int year, int month) {
		
		switch(month){
			case 1: case 3: case 5: case 7: case 8: case 10: case 12:
				return 31;
			case 4: case 6: case 9: case 11:
				return 30;
			case 2:
				return isLeafYear(year) == true ? 29 : 28;
			
		}
		return 0;
	}
	
	
}
