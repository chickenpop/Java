package com.test.java;

public class Item28 {

	public static void main(String[] args) {

		// [SUMMARY] 배열 덤프 (2022. 3. 20. 오전 11:44:14)
		
		int[] list = new int[5];
		for(int i=0; i<list.length; i++) {
			
			list[i] = i+1;
			
		}
		System.out.println(dump(list));
		
	}

	public static String dump(int[] ns) {
		
		String result = "[";
		
		for(int i=0; i<ns.length; i++) {
			
			if(i == ns.length-1) {
				result += ns[i]; 
				break;
			}
			result += ns[i] + ", ";
			
		}
		
		result += "]";
		return result;
	}
	
}
