package com.test.java;

import java.util.Arrays;

public class Item29 {

	public static void main(String[] args) {

		// [SUMMARY] 버블정렬 (2022. 3. 20. 오전 11:46:40)
	
		int[] list = { 5, 3, 1, 4, 2 };

		for(int i=0; i<list.length-1; i++) {
			for(int j=0; j<list.length-i-1; j++) {
				
				if(list[j] > list[j+1]) { // 오름차순, < 내림차순
					int temp = list[j];
					list[j] = list[j+1];
					list[j+1] = temp;	
				}
				
			}
		}
		
		System.out.println(Arrays.toString(list));
	
	}
	
}
