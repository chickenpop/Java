package com.test.java;

public class Item30 {

	public static void main(String[] args) {
		
		// [SUMMARY] 문자열 비교 (2022. 3. 20. 오후 12:24:33)

		String[] name = {"나나나", "가가가", "가가가"};
		
		// name1 > name2 : 양수 반환
		System.out.println(name[0].compareTo(name[1])); // 양수
		// name1 < name2 : 음수 반환
		System.out.println(name[1].compareTo(name[0])); // 음수
		// name1 == name2 : 0
		System.out.println(name[2].compareTo(name[1])); // 0
		
		
	}

}
