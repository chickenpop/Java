package com.test.java;

public class Item31 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 메소드 trim() (2022. 3. 21. 오후 9:13:15)
		// 문자열의 앞뒤 공백 문자를 제거함
		// 중간에 있는 공백은 제거하지 않음
		
		String txt = "    하나    둘    셋    ";
		
		System.out.printf("[%s]\n", txt);
		System.out.printf("[%s]\n", txt.trim());
		
	}

}
