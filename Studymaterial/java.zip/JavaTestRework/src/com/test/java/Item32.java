package com.test.java;

public class Item32 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 메소드 indexOf() (2022. 3. 21. 오후 9:14:30)
		// 문자열 내에서 원하는 문자의 위치를 반환함
		// 처음 만난 위치만 반환함
		// 문자, 문자열 둘다 같은 형태로 사용가능
		
		String txt = "안녕하세요. 홍길동입니다. 반갑습니다. 홍길동입니다. 네 홍길동입니다.";
		
		int index = -1;
		
		// 문자
		index = txt.indexOf('하');    // 2
		System.out.println(index);
		
		// 없는 문자
		index = txt.indexOf('강');    // -1
		System.out.println(index);
		
		// 문자열
		index = txt.indexOf("홍"); 	 // 7
		System.out.println(index);
		
		// 시작 값 지정
		index = txt.indexOf("홍길동", index+1); //22, 첫번째 문자의 위치를 반환
		System.out.println(index);
		System.out.println();
	
	}

}
