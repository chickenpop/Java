package com.test.java;

public class Item33 {

	public static void main(String[] args) {

		// [SUMMARY] 메소드 체인 (2022. 3. 21. 오후 9:19:08)
		// 문자열.메소드().메소드().메소드()
		
		String content = "알파벳 첫 시작은 ABC이다.";
		String word = "abc";
		
		if(content.toUpperCase().indexOf(word.toUpperCase())>-1) {
			System.out.println("결과 있음");
		} else {
			System.out.println("결과 없음");			
		}
	}

}
