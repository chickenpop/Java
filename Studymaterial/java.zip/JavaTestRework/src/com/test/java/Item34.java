package com.test.java;

public class Item34 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 startWith, endWith (2022. 3. 23. 오전 12:29:31)
	
		String txt = "자바 오라클 프로그래밍";
		
		System.out.println(txt.startsWith("자바"));
		System.out.println(txt.startsWith("오라클"));
		
		System.out.println(txt.endsWith("프로그래밍"));
		System.out.println(txt.endsWith("오라클"));
	}

}
