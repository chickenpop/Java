package com.test.java;

public class Item35 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 lastIndexOf (2022. 3. 23. 오전 12:31:04)
		
		String txt = "홍길동 자바 공부 홍길동";
		
		System.out.println(txt.lastIndexOf("홍길동"));
		System.out.println(txt.lastIndexOf("홍길동", 5));
		
	}

}
