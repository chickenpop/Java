package com.test.java;

public class Item36 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 substring() (2022. 3. 23. 오전 12:32:40)
		// 시작 인덱스 : 포함(inclusive)
		// 마지막 인덱스 : 미포함(exclusive)
		
		String txt = "가나다라마바사아자차카타파하";
		
		System.out.println(txt.substring(3, 7));
		
		
	}

}
