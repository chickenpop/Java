package com.test.java;

import java.util.Arrays;

public class Item37 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 > 문자 배열 (2022. 3. 23. 오전 12:34:13)
		
		String txt = "홍길동입니다.";
		
		char[] clist = txt.toCharArray();
		
		System.out.println(Arrays.toString(clist));
	}

}
