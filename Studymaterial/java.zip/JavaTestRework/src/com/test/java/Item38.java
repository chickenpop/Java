package com.test.java;

import java.util.Arrays;

public class Item38 {

	public static void main(String[] args) {

		// [SUMMARY] 문자열 split() (2022. 3. 23. 오전 12:35:36)
		
		String email = "abcd123@gmail.com";
		String[] split = email.split("@");
		
		System.out.println(Arrays.toString(split));
		
		
	}

}
